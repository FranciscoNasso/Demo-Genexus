@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEOSynchronizationEventsAPI <NSObject>

- (instancetype)init;

+ (BOOL)hasevents:(NSInteger)EventStatus  NS_SWIFT_NAME(hasevents(_:));
+ (GXObjectCollection *)getevents:(NSInteger)EventStatus  NS_SWIFT_NAME(getevents(_:));
+ (void)markeventaspending:(GXUUID *)EventGUID  NS_SWIFT_NAME(markeventaspending(_:));
+ (void)removeevent:(GXUUID *)EventGUID  NS_SWIFT_NAME(removeevent(_:));

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOSynchronizationEventsAPI)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOSynchronizationEventsAPI> gxEOClass_GXEOSynchronizationEventsAPI;

@end

NS_ASSUME_NONNULL_END
