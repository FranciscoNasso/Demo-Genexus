@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEOClientInformation <NSObject>

- (instancetype)init;

@property(nonatomic, readonly) NSString * deviceId NS_SWIFT_NAME(deviceId);
@property(nonatomic, readonly) NSString * osName NS_SWIFT_NAME(osName);
@property(nonatomic, readonly) NSString * osVersion NS_SWIFT_NAME(osVersion);
@property(nonatomic, readonly) NSString * language NS_SWIFT_NAME(language);
@property(nonatomic, readonly) NSInteger deviceType NS_SWIFT_NAME(deviceType);
@property(nonatomic, readonly) NSString * platformName NS_SWIFT_NAME(platformName);
@property(nonatomic, readonly) NSString * appVersionCode NS_SWIFT_NAME(appVersionCode);
@property(nonatomic, readonly) NSString * appVersionName NS_SWIFT_NAME(appVersionName);
@property(nonatomic, readonly) NSString * applicationId NS_SWIFT_NAME(applicationId);

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOClientInformation)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOClientInformation> gxEOClass_GXEOClientInformation;

@end

NS_ASSUME_NONNULL_END
