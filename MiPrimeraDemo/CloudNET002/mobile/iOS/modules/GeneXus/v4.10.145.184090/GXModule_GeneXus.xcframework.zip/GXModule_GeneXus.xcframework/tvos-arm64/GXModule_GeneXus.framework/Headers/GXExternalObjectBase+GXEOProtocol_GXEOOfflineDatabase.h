@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEOOfflineDatabase <NSObject>

- (instancetype)init;

+ (NSInteger)backup:(NSString *)Path  NS_SWIFT_NAME(backup(_:));
+ (NSInteger)restore:(NSString *)Path  NS_SWIFT_NAME(restore(_:));

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOOfflineDatabase)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOOfflineDatabase> gxEOClass_GXEOOfflineDatabase;

@end

NS_ASSUME_NONNULL_END
