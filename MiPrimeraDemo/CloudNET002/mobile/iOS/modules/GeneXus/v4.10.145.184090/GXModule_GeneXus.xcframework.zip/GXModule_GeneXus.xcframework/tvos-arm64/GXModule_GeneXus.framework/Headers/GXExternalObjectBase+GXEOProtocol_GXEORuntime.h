@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEORuntime <NSObject>

- (instancetype)init;

@property(nonatomic, readonly) NSInteger environment NS_SWIFT_NAME(environment);
@property(nonatomic, readwrite) NSInteger exitCode NS_SWIFT_NAME(exitCode);

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEORuntime)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEORuntime> gxEOClass_GXEORuntime;

@end

NS_ASSUME_NONNULL_END
