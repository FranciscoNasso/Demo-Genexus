@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEOLog <NSObject>

- (instancetype)init;

+ (void)write:(NSString *)message  NS_SWIFT_NAME(write(_:));
+ (void)write:(NSString *)message :(NSString *)topic :(NSInteger)logLevel  NS_SWIFT_NAME(write(_:_:_:));
+ (void)error:(NSString *)message :(NSString *)topic  NS_SWIFT_NAME(error(_:_:));
+ (void)error:(NSString *)message  NS_SWIFT_NAME(error(_:));
+ (void)warning:(NSString *)message :(NSString *)topic  NS_SWIFT_NAME(warning(_:_:));
+ (void)warning:(NSString *)message  NS_SWIFT_NAME(warning(_:));
+ (void)info:(NSString *)message :(NSString *)topic  NS_SWIFT_NAME(info(_:_:));
+ (void)info:(NSString *)message  NS_SWIFT_NAME(info(_:));
+ (void)debug:(NSString *)message :(NSString *)topic  NS_SWIFT_NAME(debug(_:_:));
+ (void)debug:(NSString *)message  NS_SWIFT_NAME(debug(_:));
+ (void)fatal:(NSString *)message :(NSString *)topic  NS_SWIFT_NAME(fatal(_:_:));
+ (void)fatal:(NSString *)message  NS_SWIFT_NAME(fatal(_:));

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOLog)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOLog> gxEOClass_GXEOLog;

@end

NS_ASSUME_NONNULL_END
