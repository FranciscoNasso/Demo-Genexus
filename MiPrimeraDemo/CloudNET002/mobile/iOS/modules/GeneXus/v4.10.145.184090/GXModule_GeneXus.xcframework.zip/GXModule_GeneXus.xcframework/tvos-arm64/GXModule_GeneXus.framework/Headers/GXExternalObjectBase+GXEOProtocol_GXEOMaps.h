@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN

@class genexus_common_SdtDirections;
@class genexus_common_SdtLocationInfo;
@class genexus_common_SdtLocationProximityAlert;
@class genexus_common_SdtDirectionsRequestParameters;

@protocol GXEOProtocol_GXEOMaps <NSObject>

- (instancetype)init;

@property(nonatomic, readonly) NSInteger authorizationStatusNumber NS_SWIFT_NAME(authorizationStatusNumber);
@property(nonatomic, readonly) BOOL locationservicesauthorized NS_SWIFT_NAME(locationservicesauthorized);
@property(nonatomic, readonly) BOOL locationservicesenabled NS_SWIFT_NAME(locationservicesenabled);
@property(nonatomic, readonly) NSInteger authorizedAccuracy NS_SWIFT_NAME(authorizedAccuracy);

+ (genexus_common_SdtDirections *)calculatedirections:(NSString *)sourceLocation :(NSString *)destinationLocation  NS_SWIFT_NAME(calculatedirections(_:_:));
+ (genexus_common_SdtDirections *)calculatedirections:(NSString *)sourceLocation :(NSString *)destinationLocation :(NSString *)transportType :(BOOL)requestAlternateRoutes  NS_SWIFT_NAME(calculatedirections(_:_:_:_:));
+ (genexus_common_SdtDirections *)calculatedirections:(genexus_common_SdtDirectionsRequestParameters *)DirectionsParameters  NS_SWIFT_NAME(calculatedirections(_:));
+ (genexus_common_SdtLocationInfo *)getmylocation:(NSInteger)minAccuracy :(NSInteger)timeout :(BOOL)includeHeadingAndSpeed  NS_SWIFT_NAME(getmylocation(_:_:_:));
+ (genexus_common_SdtLocationInfo *)getmylocation:(NSInteger)minAccuracy :(NSInteger)timeout :(BOOL)includeHeadingAndSpeed :(BOOL)ignoreErrors  NS_SWIFT_NAME(getmylocation(_:_:_:_:));
+ (NSDecimal)getlatitude:(NSString *)location  NS_SWIFT_NAME(getlatitude(_:));
+ (NSDecimal)getlongitude:(NSString *)location  NS_SWIFT_NAME(getlongitude(_:));
+ (GXObjectCollection *)getaddress:(NSString *)location  NS_SWIFT_NAME(getaddress(_:));
+ (GXObjectCollection *)getlocation:(NSString *)address  NS_SWIFT_NAME(getlocation(_:));
+ (BOOL)setproximityalerts:(GXObjectCollection *)proximityAlerts  NS_SWIFT_NAME(setproximityalerts(_:));
+ (GXObjectCollection *)getproximityalerts NS_SWIFT_NAME(getproximityalerts());
+ (genexus_common_SdtLocationProximityAlert *)getcurrentproximityalert NS_SWIFT_NAME(getcurrentproximityalert());
+ (void)clearproximityalerts NS_SWIFT_NAME(clearproximityalerts());
+ (NSDecimal)getDecimalDistance:(NSString *)fromLocation :(NSString *)toLocation  NS_SWIFT_NAME(getDecimalDistance(_:_:));

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOMaps)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOMaps> gxEOClass_GXEOMaps;

@end

NS_ASSUME_NONNULL_END
