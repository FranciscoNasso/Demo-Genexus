@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEOCrashAnalytics <NSObject>

- (instancetype)init;

@property(nonatomic, readonly) BOOL isEnabled NS_SWIFT_NAME(isEnabled);

+ (BOOL)didCrashOnPreviousExecution NS_SWIFT_NAME(didCrashOnPreviousExecution());
+ (void)setCustomKey:(NSString *)Key :(NSString *)Value  NS_SWIFT_NAME(setCustomKey(_:_:));
+ (void)setCustomKeys:(GXObjectCollection *)CustomKeysAndValues  NS_SWIFT_NAME(setCustomKeys(_:));
+ (void)removeCustomKey:(NSString *)Key  NS_SWIFT_NAME(removeCustomKey(_:));
+ (void)setUserId:(NSString *)UserId  NS_SWIFT_NAME(setUserId(_:));
+ (void)log:(NSString *)Message  NS_SWIFT_NAME(log(_:));

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOCrashAnalytics)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOCrashAnalytics> gxEOClass_GXEOCrashAnalytics;

@end

NS_ASSUME_NONNULL_END
