@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEOAppearance <NSObject>

- (instancetype)init;

@property(nonatomic, readonly) NSInteger preferredColorScheme NS_SWIFT_NAME(preferredColorScheme);

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOAppearance)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOAppearance> gxEOClass_GXEOAppearance;

@end

NS_ASSUME_NONNULL_END
