@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEOClientSocket <NSObject>

- (instancetype)init;

@property(nonatomic, readonly) NSInteger status NS_SWIFT_NAME(status);

+ (void)open:(NSString *)url  NS_SWIFT_NAME(open(_:));
+ (void)close NS_SWIFT_NAME(close());
+ (void)send:(NSString *)msg  NS_SWIFT_NAME(send(_:));

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOClientSocket)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOClientSocket> gxEOClass_GXEOClientSocket;

@end

NS_ASSUME_NONNULL_END
